package com.example.ovensync;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity {
    private static Button solar;
    private static Button electric;

    private static Button hybrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        solar = (Button) findViewById(R.id.solar);
        solar.setOnClickListener((v)->{
            Intent ht2 = new Intent(MainActivity2.this,MainActivity3.class);
            startActivity(ht2);
        });

        electric = (Button) findViewById(R.id.electric);
        electric.setOnClickListener((v)->{
            Intent ht3 = new Intent(MainActivity2.this,MainActivity4.class);
            startActivity(ht3);
        });

        hybrid = (Button) findViewById(R.id.hybrid);
        hybrid.setOnClickListener((v)->{
            Intent ht7 = new Intent(MainActivity2.this,MainActivity6.class);
            startActivity(ht7);
        });
    }
}