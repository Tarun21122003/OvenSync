package com.example.ovensync;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.EditText;
import static com.example.ovensync.MainActivity.texr;
public class MainActivity6 extends AppCompatActivity {
    private EditText temp5;
    private EditText time5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        temp5 = findViewById(R.id.temp5);
        time5 = findViewById(R.id.time5);
        Button startoven = findViewById(R.id.startoven5);





        startoven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ipadd = texr.toString(); // Assuming texr is your EditText for IP
                String temperature = temp5.getText().toString();
                String duration = time5.getText().toString();

                // Check if temperature or time is empty
                if (temperature.isEmpty() || duration.isEmpty()) {
                    Toast.makeText(MainActivity6.this, "Please enter temperature and time", Toast.LENGTH_SHORT).show();
                } else {
                    int tempValue = Integer.parseInt(temperature);
                    int timeValue = Integer.parseInt(duration);

                    // Check if temperature or time exceeds certain limits
                    if (tempValue > 400 && timeValue > 600) {
                        Toast.makeText(MainActivity6.this, "Temperature and time exceed limits", Toast.LENGTH_SHORT).show();
                    } else if (tempValue > 400) {
                        Toast.makeText(MainActivity6.this, "Temperature exceeds limit", Toast.LENGTH_SHORT).show();
                    } else if (timeValue > 600) {
                        Toast.makeText(MainActivity6.this, "Time exceeds limit", Toast.LENGTH_SHORT).show();
                    } else {
                        StartOvenH process1 = new StartOvenH(ipadd, temperature, duration);
                        process1.execute();
                    }
                }
            }
        });



    }
}
