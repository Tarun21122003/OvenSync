package com.example.ovensync;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static com.example.ovensync.MainActivity.texr;
public class MainActivity3 extends AppCompatActivity {
    private EditText temp2;
    private EditText time2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        temp2 = findViewById(R.id.temp2);
        time2 = findViewById(R.id.time2);
        Button startoven2 = findViewById(R.id.StartOven2);


        startoven2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ipadd = texr.toString(); // Assuming texr is your EditText for IP
                String temperature = temp2.getText().toString();
                String duration = time2.getText().toString();

                if (temperature.isEmpty() || duration.isEmpty()) {
                    Toast.makeText(MainActivity3.this, "Please enter temperature and time", Toast.LENGTH_SHORT).show();
                } else {
                    int tempValue = Integer.parseInt(temperature);
                    int timeValue = Integer.parseInt(duration);

                    // Check if temperature or time exceeds certain limits
                    if (tempValue > 400 && timeValue > 600) {
                        Toast.makeText(MainActivity3.this, "Temperature and time exceed limits", Toast.LENGTH_SHORT).show();
                    } else if (tempValue > 400) {
                        Toast.makeText(MainActivity3.this, "Temperature exceeds limit", Toast.LENGTH_SHORT).show();
                    } else if (timeValue > 600) {
                        Toast.makeText(MainActivity3.this, "Time exceeds limit", Toast.LENGTH_SHORT).show();
                    } else {
                        StartOvenS process1 = new StartOvenS(ipadd, temperature, duration);
                        process1.execute();
                    }
                }
            }
        });
    }
}

