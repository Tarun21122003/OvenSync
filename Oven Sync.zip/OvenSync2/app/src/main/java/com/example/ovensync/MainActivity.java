package com.example.ovensync;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.SharedPreferences;

public class MainActivity extends AppCompatActivity {
    private EditText ipxx1;

    private static Button ovencontrols;

    private SharedPreferences sharedPreferences;

    private static final String IP_ADDRESS_KEY = "ip_address";
    private Button recipesButton;

    private String[] recipes = {
            "Spaghetti Carbonara",
            "Grilled Salmon",
            "Chicken Stir-Fry",
            "Vegetable Curry"
    };
    private int[] cookingTemperatures = {180, 200, 220, 160};



    private static Button okButton;
    private static Button connect;
    public static String texr;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ipxx1 = (EditText) findViewById(R.id.ipadd);

        connect = (Button) findViewById(R.id.connect);

        recipesButton = findViewById(R.id.recipes);
        okButton = findViewById(R.id.ok1);
        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String savedIpAddress = sharedPreferences.getString(IP_ADDRESS_KEY, "");
        ipxx1.setText(savedIpAddress);


        recipesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the new activity here
                Intent intent = new Intent(MainActivity.this, RecipeActivity.class);
                startActivity(intent);
            }
        });

        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the entered IP address
                String ipAddress = ipxx1.getText().toString().trim();

                // Save the IP address in SharedPreferences
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(IP_ADDRESS_KEY, ipAddress);
                editor.apply();

                // You can now use the ipAddress for your connection logic
            }
        });


        connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open MainActivity5 when the button is clicked
                Intent intent = new Intent(MainActivity.this, MainActivity5.class);
                startActivity(intent);
            }
        });

        ovencontrols = (Button) findViewById(R.id.ovencontrols);
        ovencontrols.setOnClickListener((v)->{
            texr = ipxx1.getText().toString();
            Intent ht1 = new Intent(MainActivity.this,MainActivity2.class);
            startActivity(ht1);
        });
    }
}
