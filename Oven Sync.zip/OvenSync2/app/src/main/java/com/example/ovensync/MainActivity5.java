package com.example.ovensync;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity5 extends AppCompatActivity {
    EditText editTextSSID, editTextPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        editTextSSID = findViewById(R.id.editTextSSID);
        editTextPassword = findViewById(R.id.editTextPassword);
    }

    public void connectToArduino(View view) {
        String ssid = editTextSSID.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        new SendDataToArduino().execute(ssid, password);
    }

    private class SendDataToArduino extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            String ssid = params[0];
            String password = params[1];

            try {
                URL url = new URL("http://192.168.4.1/connect");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);

                String postData = "ssid=" + ssid + "&password=" + password;
                OutputStream os = conn.getOutputStream();
                os.write(postData.getBytes());
                os.flush();
                os.close();

                int responseCode = conn.getResponseCode();
                Log.d("HTTP Response", "Code: " + responseCode);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}

