package com.example.ovensync;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class RecipeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);

        // Get the TextView reference
        TextView recipeTextView = findViewById(R.id.recipeTextView);

        // Set the recipes and their preparation steps

        String recipeName1 = "Homemade Pizza";
        String preparationSteps1 = "1. Prepare pizza dough and let it rise.\n" +
                "2. Preheat oven to highest temperature.\n" +
                "3. Roll out dough and place on a pizza stone or baking sheet.\n" +
                "4. Spread pizza sauce evenly over the dough.\n" +
                "5. Add shredded mozzarella cheese and desired toppings.\n" +
                "6. Bake in the preheated oven until crust is golden and cheese is bubbly.\n" +
                "7. Remove from oven, slice, and serve hot.";



        String recipeName2 = "Grilled Chicken Salad";
        String preparationSteps2 = "1. Marinate chicken with olive oil, lemon juice, and herbs.\n" +
                "2. Preheat grill and cook chicken until done.\n" +
                "3. Chop lettuce, tomatoes, cucumbers, and onions.\n" +
                "4. Slice cooked chicken and add to salad.\n" +
                "5. Drizzle with dressing of your choice.\n" +
                "6. Toss well and serve.";





        String recipeName3 = "Classic Burger";
        String preparationSteps3 = "1. Season ground beef with salt and pepper.\n" +
                "2. Form into patties and grill or cook in a skillet to desired doneness.\n" +
                "3. Toast burger buns on the grill or in a toaster.\n" +
                "4. Assemble burgers with lettuce, tomato, onion, cheese, pickles, and condiments.\n" +
                "5. Serve hot with fries or a side salad.";

        String recipeName4 = "French Fries";
        String preparationSteps4 = "1. Wash and peel potatoes, then cut them into strips.\n" +
                "2. Soak the potato strips in cold water for about 30 minutes to remove excess starch.\n" +
                "3. Drain and pat dry the potato strips.\n" +
                "4. Heat oil in a deep fryer or pot to around 350°F (175°C).\n" +
                "5. Fry the potato strips in batches until golden brown and crispy.\n" +
                "6. Remove from oil, drain excess oil on paper towels, and season with salt.\n" +
                "7. Serve hot with ketchup or your favorite dipping sauce.";

        String recipeName5 = "Spaghetti Carbonara";
        String preparationSteps5 = "1. Boil water and cook spaghetti.\n" +
                "2. In a pan, cook diced pancetta until crispy.\n" +
                "3. Whisk eggs, Parmesan cheese, and black pepper in a bowl.\n" +
                "4. Drain spaghetti and toss with pancetta.\n" +
                "5. Remove from heat and stir in egg mixture.\n" +
                "6. Serve immediately topped with extra Parmesan.";

        // Set the text in the TextView with all recipes
        String recipesText = getString(R.string.recipe_format, recipeName1, preparationSteps1)
                + "\n\n\n" +
                getString(R.string.recipe_format, recipeName2, preparationSteps2)
                + "\n\n\n" +
                getString(R.string.recipe_format, recipeName3, preparationSteps3)
                + "\n\n\n" +
                getString(R.string.recipe_format, recipeName4, preparationSteps4)
                + "\n\n\n" +
                getString(R.string.recipe_format, recipeName5, preparationSteps5);

        recipeTextView.setText(recipesText);
    }
}
